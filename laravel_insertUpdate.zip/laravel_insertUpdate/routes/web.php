<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/',[UserController::class,'showUser'])->name('home');

Route::get('/user/{id}',[UserController::class,'singleUser'])->name('view.user');
Route::get('/delete/{id}',[UserController::class,'deleteUser'])->name('delete.user');
Route::get('/add',[UserController::class,'addUser']);
Route::get('/edit',[UserController::class,'updateUser']);

