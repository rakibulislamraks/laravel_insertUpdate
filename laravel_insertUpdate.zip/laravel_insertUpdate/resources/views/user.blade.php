<h1>single user</h1>

@foreach ($data as $id => $user)
    <h3>{{$user->name}}</h3>
    <h3>{{$user->age}}</h3>
    <h3>{{$user->email}}</h3>
    <h3>{{$user->city}}</h3>
    <h3>{{$user->address}}</h3>

@endforeach