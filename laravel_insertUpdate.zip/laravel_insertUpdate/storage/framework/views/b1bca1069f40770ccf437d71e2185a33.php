<h1>single user</h1>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3><?php echo e($user->name); ?></h3>
    <h3><?php echo e($user->age); ?></h3>
    <h3><?php echo e($user->email); ?></h3>
    <h3><?php echo e($user->city); ?></h3>
    <h3><?php echo e($user->address); ?></h3>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\laravel\example-app\resources\views/user.blade.php ENDPATH**/ ?>