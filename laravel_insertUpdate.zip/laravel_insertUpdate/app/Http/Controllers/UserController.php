<?php

namespace App\Http\Controllers;
use Illuminate\support\Facades\DB;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function showUser(){
        $users = DB::table('students')->get();
        // return $users;
        return view('welcome',['data'=>$users]);
    }
    public function singleUser(string $id){
        $users = DB::table('students')->where('id',$id)->get();
        // return $users;
        return view('user',['data'=>$users]);
    }
    public function addUser(){
        $users = DB::table('students')->upsert([
            'name'=> 'Rakibul Islam',
            'age'=>23,
            'email'=>'sukhen03@gmail.com',
            'address'=>'kolapara_banra-43',
            'city'=>'kolapara',
            'phone'=>'01614167842',
            'password'=>'sumon321',
           
        ],
        [
            'email'
        ]
    );
//     $users = DB::table('students')->insertOrIgnore([
//         'name'=> 'Rakibul Islam',
//         'age'=>23,
//         'email'=>'raja03@gmail.com',
//         'address'=>'amtali_banra-43',
//         'city'=>'amtali',
//         'phone'=>'01792683417',
//         'password'=>'rakavai321',
       
//     ]
// );
        if($users){
            echo "<h3>Data Added successfully!</h3>";
        }
        else{
            echo "<h3>Data Already exist!</h3>";
        }
       
    }
    public function updateUser(){
        $users = DB::table('students')->where('id',4)->update([
            'name'=>'Moon',
            'email'=>'moonislam5@gmail.com'
        ]);
        if($users){
            echo "<h3>Data update successfully!</h3>";
        }
        else{
            echo "<h3>Data updated failed!</h3>";
        }
        // return $users;
        // return view('user',['data'=>$users]);
    }
    public function deleteUser(string $id){
        $users = DB::table('students')->where('id',$id)->delete();
        if($users){
            return redirect()->route('home');
        }
        
        // return $users;
        // return view('user',['data'=>$users]);
    }

}
